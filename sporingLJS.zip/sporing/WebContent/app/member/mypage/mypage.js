function changeGenColor() {
	let test = document.getelementById("test");
	if (test == "남자"){
		test.style.backgroundColor = "red";
	}
	else {
		test.style.backgroundColor = "blue";
	}
}



changeGenColor();

